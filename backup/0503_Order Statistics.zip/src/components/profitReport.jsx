// components/ProfitReport.jsx
import React from 'react';
import { Typography, Tag } from 'antd';
import Chart from 'react-apexcharts';

const { Title, Text } = Typography;

const ProfitReport = () => {
  const options = {
    chart: {
      type: 'line',
      sparkline: { enabled: true }
    },
    stroke: {
      curve: 'smooth',
      width: 4
    },
    colors: ['#f59e0b'],
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        type: 'horizontal',
        gradientToColors: ['#fde68a'],
        stops: [0, 100]
      }
    },
    tooltip: { enabled: false }
  };

  const series = [
    {
      name: 'Profit',
      data: [10, 40, 20, 35, 30, 60]
    }
  ];

  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', height: '100%',textAlign: 'left' }}>
      <div>
        <Text style={{ color: '#6B7280', fontSize: 20 }}>Profit Report</Text>
        <div style={{ margin: '10px 0' }}>
          <Tag color="gold" style={{ fontWeight: 500 }}>YEAR 2025</Tag>
        </div>
        <Text style={{ color: '#10B981', fontWeight: 600 }}>▲ 68.2%</Text>
        <Title level={3} style={{ margin: 0 }}>$84,686k</Title>
      </div>
      <div style={{ width: '65%', height: '100%' }}>
        <Chart options={options} series={series} type="line" height="100%" />
      </div>
    </div>
  );
};

export default ProfitReport;

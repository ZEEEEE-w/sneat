
import React from 'react';
import Chart from 'react-apexcharts';

const BasicLineChart = () => {

  const data = [10, 41, 35, 51, 49, 62, 69, 91, 148];

  const series = [
    {
      data
    }
  ];

  const options = {
    chart: {
      type: 'area',
      sparkline: { enabled: true },   
      toolbar: { show: false },
      zoom:    { enabled: false },
      offsetY: 0,                    
      offsetX: 0,                      
      padding: {                     
        top:    0,
        bottom: 0,
        left:   0,
        right:  0
      }
    },
    stroke: {
      curve: 'smooth',
      width: 3
    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        type: 'vertical',
        shadeIntensity: 0.6,
        inverseColors: false,
        opacityFrom: 0.6,
        opacityTo: 0,
        stops: [0, 100]
      }
    },
    colors: ['#59E296'],
    markers: {
      size: 4,
      colors: ['#59E296'],
      strokeColors: '#fff',
      strokeWidth: 2,
      discrete: [
        {
          seriesIndex: 0,
          dataPointIndex: data.length - 1,
          fillColor: '#fff',
          strokeColor: '#59E296',
          size: 6
        }
      ]
    },
    tooltip: { enabled: false }
  };

  return (
    <Chart
      options={options}
      series={series}
      type="area"
      width="100%"
      height="100%"
    />
  );
};

export default BasicLineChart;


import React from 'react';
import { MoreOutlined, ArrowUpOutlined ,AccountBookTwoTone } from '@ant-design/icons';
// import walletIcon from '@/assets/wallet-icon.svg'; 

const SalesCard = () => {
  return (
    <  >
      <div className="sales-card__header">
        <div className="sales-card__icon">
        <AccountBookTwoTone />
        </div>
        <MoreOutlined className="sales-card__more" />
      </div>

      <div className="sales-card__body">
        <div className="sales-card__title">Sales</div>
        <div className="sales-card__value">$4,679</div>
        <div className="sales-card__change sales-card__change--up">
          <ArrowUpOutlined />
          <span>28.14%</span>
        </div>
      </div>
    </>
  );
};

export default SalesCard;

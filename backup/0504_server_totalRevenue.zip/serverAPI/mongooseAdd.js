
const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/sneat')

mongoose.connection.once('open', () => {
  console.log('database connected');
  let addSchema = new mongoose.Schema({
    name: String,
    data: [Number],
  })
  let addModel = mongoose.model('totalrevenuedatas', addSchema)

  addModel.insertMany([
    {name:'2024', data: [16, 5, 14, 26, 16, 10, 8]},
    {name:'2023', data: [-12, -18, -8, -14, -5, -15, -10]},
  ], (err, data) => {
    if (err) {
      console.log(err);
    }
    console.log(data);
  })
})

mongoose.connection.on('error',()=>{
  console.log('db connection error');
})
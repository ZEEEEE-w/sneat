
const {orderModel,salesModel,totalRevenueModel} = require('../model/homeModel');

exports.getOrder = async()=> {
  try{
    return await orderModel.find()
  }catch(err) {
    console.log(err);
  }
}

exports.getSales = async()=>{
  try{
    return await salesModel.find()
  }catch(err) {
    console.log(err);
  }
}

exports.getTotalRevenue = async()=>{
  try{
    return await totalRevenueModel.find()
  }catch(err) {
    console.log(err);
  }
}
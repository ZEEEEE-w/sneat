// order data route

const express = require('express');
const { getOrder,getSales,getTotalRevenue } = require('../controllers/homeController');
const router = express.Router();

router.get('/getOrder', async (req,res)=>{
  console.log('get order data suuccess');
  const orderResult = await getOrder();
  res.send(orderResult); 
})

router.get('/getSales', async(req,res)=>{
  console.log('get sales data success');
  const salesResult = await getSales();
  res.send(salesResult);
})

router.get('/getTotalRevenue', async(req,res)=>{
  console.log('get total revenue data success');
  const totalRevenueResult = await getTotalRevenue();
  res.send(totalRevenueResult);
})

module.exports = router;